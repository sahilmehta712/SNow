# SnowEdge Consultancy v0.4

Mobile-first offline ServiceNow developer companion.

Navigation: Home → ITSM → Tables → Incident → Incident deep dive.

v0.4 adds a larger ITSM table catalog, searchable tables, an Incident developer deep dive, field dictionary, data model, developer toolkit, security, troubleshooting, real-world scenarios, quizzes and an expanded developer reference.

Android 14+ (minSdk 34), target SDK 35, Gradle 8.9.
