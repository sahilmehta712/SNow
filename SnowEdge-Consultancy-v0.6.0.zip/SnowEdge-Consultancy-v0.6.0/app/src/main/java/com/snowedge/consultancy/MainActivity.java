
package com.snowedge.consultancy;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {

    LinearLayout root, top, content, bottomNav;
    TextView title, subtitle;
    EditText search;
    int blue = Color.rgb(75,123,255), lilac = Color.rgb(141,123,255);
    int bg = Color.rgb(246,248,252), text = Color.rgb(22,35,51), muted = Color.rgb(113,128,150);
    ArrayDeque<Runnable> backStack = new ArrayDeque<>();

    // Screen density, used by dp() to convert design-space dp values into real pixels.
    // Every padding / width / height / margin in this file is specified in dp and
    // must go through dp() before being handed to the Android view APIs, which only
    // understand raw pixels. Skipping that conversion is what made the previous
    // build look cramped and overlapping on higher-density screens.
    float density = 1f;
    int dp(int v){ return Math.round(v * density); }

    // Base (no-inset) padding for the header and bottom nav; the real values used at
    // runtime add the status-bar / navigation-bar inset on top of these once the
    // system reports them (see applyInsets()).
    int topBasePadTop, bottomNavBasePadBottom;

    static class TableInfo {
        String label, name, desc, icon, color;
        List<String> fields, related, automation, security, tips;
        TableInfo(String l,String n,String d,String i,String c,List<String> f,List<String> r,List<String> a,List<String> s,List<String> t){
            label=l; name=n; desc=d; icon=i; color=c; fields=f; related=r; automation=a; security=s; tips=t;
        }
    }
    static class ModuleInfo {
        String label, code, icon, blurb, accent;
        List<TableInfo> tables;
        ModuleInfo(String l,String c,String i,String b,String a,List<TableInfo> t){label=l;code=c;icon=i;blurb=b;accent=a;tables=t;}
    }

    ArrayList<ModuleInfo> modules = new ArrayList<>();
    ArrayList<String> devConcepts = new ArrayList<>(Arrays.asList(
            "GlideRecord","GlideAggregate","GlideAjax","Business Rules","Client Scripts","UI Policies","UI Actions",
            "ACLs","Script Includes","Flow Designer","Scheduled Jobs","Events","Notifications","Data Policies",
            "Scoped Applications","Application Access","Data Model","Dictionary","Reference Fields","Choice Fields",
            "Integration Design","REST APIs","Import Sets","Transform Maps","IntegrationHub","CSDM",
            "Update Sets","Source Control","ATF","Debugging","Performance","Security","Domain Separation","Delegated Development"
    ));

    TableInfo incident() {
        return new TableInfo("Incident","incident","Record and manage interruptions to normal service.",
                "⚠","#4B7BFF",
                Arrays.asList("number","caller_id","category","subcategory","service","cmdb_ci","impact","urgency","priority","assignment_group","assigned_to","short_description","description","state","close_code","close_notes"),
                Arrays.asList("task","sys_user","sys_user_group","cmdb_ci","task_sla","sys_journal_field"),
                Arrays.asList("Business Rules for assignment/state logic","Flow Designer for routing and approvals","Notifications for customer updates","SLAs via task_sla"),
                Arrays.asList("Table/field ACLs","Role-based assignment controls","Server-side validation"),
                Arrays.asList("Keep priority derived from impact/urgency where appropriate","Avoid client-only security","Use assignment groups consistently","Capture closure notes and close code")
        );
    }

    List<TableInfo> itsmTables() {
        String c="#4B7BFF";
        List<TableInfo> x=new ArrayList<>();
        x.add(new TableInfo("Incident","incident","Record and manage interruptions to normal service.","⚠",c,Arrays.asList("number","caller_id","category","subcategory","service","cmdb_ci","impact","urgency","priority","assignment_group","assigned_to","short_description","description","contact_type","business_service","parent_incident","problem_id","state","close_code","close_notes"),Arrays.asList("task","sys_user","sys_user_group","cmdb_ci","task_sla","problem","change_request","sys_journal_field"),Arrays.asList("Assignment and routing","Priority calculation","Flow Designer / Workflow","Notifications","SLA processing","Major incident process"),Arrays.asList("Table ACLs","Field ACLs","Role-based assignment controls","Server-side validation"),Arrays.asList("Priority is normally derived from impact and urgency","Do not rely on Client Scripts for authorization","Use assignment groups consistently","Capture useful closure notes and close code","Use parent/child incidents deliberately")));
        x.add(new TableInfo("Task","task","Base work record inherited by many task-based tables.","✓",c,Arrays.asList("number","state","assignment_group","assigned_to","short_description","description","opened_at","closed_at"),Arrays.asList("task","sys_user","sys_user_group"),Arrays.asList("Business Rules","Flow Designer","Notifications"),Arrays.asList("Table ACLs","Field ACLs"),Arrays.asList("Prefer standard data models","Keep ownership clear","Validate important changes server-side")));
        x.add(new TableInfo("Problem","problem","Investigate recurring or significant causes of incidents.","◉",c,Arrays.asList("number","state","assignment_group","assigned_to","short_description","description","opened_at","closed_at"),Arrays.asList("task","sys_user","sys_user_group"),Arrays.asList("Business Rules","Flow Designer","Notifications"),Arrays.asList("Table ACLs","Field ACLs"),Arrays.asList("Prefer standard data models","Keep ownership clear","Validate important changes server-side")));
        x.add(new TableInfo("Problem Task","problem_task","Activities that support a Problem investigation.","↳",c,Arrays.asList("number","state","assignment_group","assigned_to","short_description","description","opened_at","closed_at"),Arrays.asList("task","sys_user","sys_user_group"),Arrays.asList("Business Rules","Flow Designer","Notifications"),Arrays.asList("Table ACLs","Field ACLs"),Arrays.asList("Prefer standard data models","Keep ownership clear","Validate important changes server-side")));
        x.add(new TableInfo("Change Request","change_request","Plan, assess, approve and execute changes.","⇄",c,Arrays.asList("number","state","assignment_group","assigned_to","short_description","description","opened_at","closed_at","type","risk","approval","start_date","end_date","backout_plan","test_plan","implementation_plan"),Arrays.asList("task","sys_user","sys_user_group","change_task","cmdb_ci","problem","sysapproval_approver"),Arrays.asList("Business Rules","Flow Designer","Notifications","CAB flows","Conflict checks","Risk assessment"),Arrays.asList("Table ACLs","Field ACLs","Approval ACLs"),Arrays.asList("Prefer standard data models","Keep ownership clear","Validate important changes server-side","Document implementation, validation and backout")));
        x.add(new TableInfo("Change Task","change_task","Execution activities for a change request.","↳",c,Arrays.asList("number","state","assignment_group","assigned_to","short_description","description","opened_at","closed_at"),Arrays.asList("task","sys_user","sys_user_group"),Arrays.asList("Business Rules","Flow Designer","Notifications"),Arrays.asList("Table ACLs","Field ACLs"),Arrays.asList("Prefer standard data models","Keep ownership clear","Validate important changes server-side")));
        x.add(new TableInfo("Request","sc_request","Parent request for service catalog submissions.","🛒",c,Arrays.asList("number","state","assignment_group","assigned_to","short_description","description","opened_at","closed_at","requested_for","cat_item","stage","approval"),Arrays.asList("task","sys_user","sys_user_group","sc_request","sc_req_item","sc_task","sc_item_option"),Arrays.asList("Business Rules","Flow Designer","Notifications","Catalog flows","Approvals","Fulfillment"),Arrays.asList("Table ACLs","Field ACLs"),Arrays.asList("Prefer standard data models","Keep ownership clear","Validate important changes server-side","Keep the request/RITM/task hierarchy clear")));
        x.add(new TableInfo("Requested Item","sc_req_item","Catalog item instance created from a request.","R",c,Arrays.asList("number","state","assignment_group","assigned_to","short_description","description","opened_at","closed_at","requested_for","cat_item","stage","approval"),Arrays.asList("task","sys_user","sys_user_group","sc_request","sc_req_item","sc_task","sc_item_option"),Arrays.asList("Business Rules","Flow Designer","Notifications","Catalog flows","Approvals","Fulfillment"),Arrays.asList("Table ACLs","Field ACLs"),Arrays.asList("Prefer standard data models","Keep ownership clear","Validate important changes server-side","Keep the request/RITM/task hierarchy clear")));
        x.add(new TableInfo("Catalog Task","sc_task","Work item used to fulfill a Requested Item.","T",c,Arrays.asList("number","state","assignment_group","assigned_to","short_description","description","opened_at","closed_at","requested_for","cat_item","stage","approval"),Arrays.asList("task","sys_user","sys_user_group","sc_request","sc_req_item","sc_task","sc_item_option"),Arrays.asList("Business Rules","Flow Designer","Notifications","Catalog flows","Approvals","Fulfillment"),Arrays.asList("Table ACLs","Field ACLs"),Arrays.asList("Prefer standard data models","Keep ownership clear","Validate important changes server-side","Keep the request/RITM/task hierarchy clear")));
        x.add(new TableInfo("Task SLA","task_sla","Task-level SLA timing and breach information.","⏱",c,Arrays.asList("task","sla","stage","planned_end_time","business_time_left","has_breached","start_time","end_time","pause_duration"),Arrays.asList("task","contract_sla","sla_definition"),Arrays.asList("SLA engine","Pause conditions","Notifications","Escalation"),Arrays.asList("Table ACLs","Field ACLs"),Arrays.asList("Understand schedules and pause conditions","Inspect task_sla when troubleshooting timing")));
        x.add(new TableInfo("Knowledge","kb_knowledge","Reusable support knowledge article.","K",c,Arrays.asList("number","kb_knowledge_base","short_description","text","workflow_state","published","valid_to","author"),Arrays.asList("kb_knowledge_base","kb_category","sys_user"),Arrays.asList("Knowledge workflows","Approvals","Notifications","Feedback"),Arrays.asList("Table ACLs","Field ACLs"),Arrays.asList("Write searchable, audience-appropriate content")));
        x.add(new TableInfo("Approval","sysapproval_approver","Approval record used by platform approval processes.","✓",c,Arrays.asList("document_id","approver","state","comments","sysapproval"),Arrays.asList("sys_user","task"),Arrays.asList("Approval flows","Notifications"),Arrays.asList("Approval read/write ACLs"),Arrays.asList("Separate approval state from task state","Make approver selection deterministic")));

        // The tables below reuse the same underlying task-style shape but each plays a
        // distinct role in ITSM — the notes here describe that specific role rather
        // than generic task boilerplate.
        x.add(new TableInfo("Service Offering","service_offering","A customer- or team-facing variant of a parent business/technical service.","S",c,
                Arrays.asList("name","parent (service)","owned_by","support_group","operational_status","service_classification"),
                Arrays.asList("cmdb_ci_service","business_service","sys_user_group"),
                Arrays.asList("CSDM service mapping keeps offerings tied to a parent service","Operational status changes can drive service health dashboards"),
                Arrays.asList("Service ownership ACLs","Support group visibility rules"),
                Arrays.asList("Model one offering per customer-facing variant, not per team","Reference the CI instead of duplicating its attributes here")));
        x.add(new TableInfo("SLA Definition","contract_sla","Defines the conditions, duration and schedule an SLA is measured against.","⏱",c,
                Arrays.asList("name","table","start_condition","pause_condition","stop_condition","duration","schedule","type"),
                Arrays.asList("task_sla","cmdb_ci_service","sys_user_group"),
                Arrays.asList("The SLA engine evaluates start/pause/stop conditions in real time","Editing a definition does not retroactively re-run existing task_sla records"),
                Arrays.asList("Restrict definition edits — they affect reporting and contractual commitments"),
                Arrays.asList("Test conditions against real sample records before activating","Watch for two definitions unintentionally matching the same task")));
        x.add(new TableInfo("Assignment Group","sys_user_group","Group record used for routing, approvals and ownership.","G",c,
                Arrays.asList("name","manager","parent","type","active","email"),
                Arrays.asList("sys_user_grmember","task.assignment_group","cmdb_ci.support_group"),
                Arrays.asList("Group membership drives assignment rules, approvals and notification distribution"),
                Arrays.asList("Restrict who can add or remove members — membership often gates data visibility via ACLs"),
                Arrays.asList("Keep group naming and hierarchy consistent across modules","Avoid one oversized catch-all group — it defeats routing logic")));
        x.add(new TableInfo("User","sys_user","Core platform identity record referenced by tasks, approvals and groups.","U",c,
                Arrays.asList("user_name","name","email","manager","department","active"),
                Arrays.asList("sys_user_grmember (→ sys_user_group)","sys_user_has_role","task.assigned_to / caller_id"),
                Arrays.asList("Provisioning and deactivation flows often sync from HR or SSO/LDAP"),
                Arrays.asList("sys_user is referenced everywhere — field ACLs matter even on a 'harmless' reference field"),
                Arrays.asList("Never hardcode a specific user in logic — reference a role or group instead","Deactivate, don't delete, users with historical records")));
        x.add(new TableInfo("Journal Entry","sys_journal_field","Stores journal-style history such as comments and work notes.","J",c,
                Arrays.asList("element (e.g. comments, work_notes)","value","name (source table)","element_id (record)","sys_created_by","sys_created_on"),
                Arrays.asList("any table with a journal field, e.g. incident.comments / incident.work_notes"),
                Arrays.asList("New journal input can trigger notifications or Business Rules on insert"),
                Arrays.asList("Journal-level ACLs can separate customer-visible comments from internal work notes"),
                Arrays.asList("Treat journal text as unstructured history — don't parse it for logic","Comments vs. work notes has real visibility consequences — pick the right one")));
        x.add(new TableInfo("Incident Metric","incident_metric","Time- and count-based metrics captured against an incident for reporting.","M",c,
                Arrays.asList("definition","table","field","value","start (sys_created_on)","end"),
                Arrays.asList("metric_definition","incident"),
                Arrays.asList("Populated automatically by Metric Definitions, e.g. time-in-state or reassignment count"),
                Arrays.asList("Typically read-only reporting data — restrict via role rather than table ACL"),
                Arrays.asList("Use it for trend reporting like MTTR, not real-time decision logic","Cross-check the underlying metric definition before trusting a dashboard number")));
        x.add(new TableInfo("Major Incident","major_incident","Coordination workflow that promotes a high-impact incident for dedicated handling.","★",c,
                Arrays.asList("major_incident_state (Candidate/Approved/Declined)","related incident","communication plan owner"),
                Arrays.asList("incident","sys_user_group (major incident manager)"),
                Arrays.asList("Candidate → Review → Approved workflow triggers stakeholder communication"),
                Arrays.asList("Only specific roles can approve or decline major incident candidacy"),
                Arrays.asList("Define objective promotion criteria up front","Assign a single communication owner to avoid mixed messaging")));
        x.add(new TableInfo("Service","cmdb_ci_service","Service CI that gives an incident or change its business context.","◇",c,
                Arrays.asList("name","service_classification","owned_by","support_group","operational_status","business_criticality"),
                Arrays.asList("cmdb_ci (via relationships)","business_service","incident.business_service"),
                Arrays.asList("Service Mapping keeps service-to-CI relationships current"),
                Arrays.asList("Service ownership and visibility ACLs"),
                Arrays.asList("Keep one authoritative service model (CSDM) instead of parallel 'service' concepts per team")));
        x.add(new TableInfo("Incident Alert","incident_alert","Correlation link between an operational alert and the incident it produced.","!",c,
                Arrays.asList("incident (reference)","alert (reference)","correlation_id"),
                Arrays.asList("em_alert","em_event","incident"),
                Arrays.asList("Alert Management rules decide whether an alert auto-creates or updates an incident"),
                Arrays.asList("Operational ACLs separate raw event/alert noise from curated incidents"),
                Arrays.asList("Tune correlation rules before enabling auto-incident creation, or you'll flood the queue")));
        x.add(new TableInfo("Incident Child","incident_child","Parent/child grouping for incidents sharing one root cause.","↳",c,
                Arrays.asList("parent_incident","child incident number","sys_id"),
                Arrays.asList("incident (self-referencing)","problem"),
                Arrays.asList("Bulk state-sync options can optionally propagate a parent's resolution to its children"),
                Arrays.asList("Same ACLs as standard incident access"),
                Arrays.asList("Use parent/child to group symptoms under one root cause","Don't use it as a substitute for proper Problem Management")));
        return x;
    }

    List<ModuleInfo> buildModules(){
        ArrayList<ModuleInfo> ms=new ArrayList<>();
        ms.add(new ModuleInfo("IT Service Management","ITSM","✦","Incidents, requests, problems, changes and service operations.","#4B7BFF",itsmTables()));
        ms.add(new ModuleInfo("Configuration Management","CMDB","⌘","CIs, relationships, service context and CMDB governance.","#7C6CFF",Arrays.asList(
                new TableInfo("Configuration Item","cmdb_ci","Base CMDB CI table for infrastructure and application configuration items.","C","#7C6CFF",Arrays.asList("name","class","install_status","operational_status","owned_by","support_group","business_service"),Arrays.asList("cmdb_rel_ci","sys_user","sys_user_group"),Arrays.asList("Discovery","Service Mapping","Identification/Reconciliation"),Arrays.asList("CI visibility ACLs"),Arrays.asList("Preserve CI ownership and class consistency")),
                new TableInfo("Server","cmdb_ci_server","Server CIs extending the base CI model.","S","#7C6CFF",Arrays.asList("name","os","ip_address","cpu_count","ram","environment"),Arrays.asList("cmdb_ci","cmdb_rel_ci"),Arrays.asList("Discovery"),Arrays.asList("Infrastructure ACLs"),Arrays.asList("Avoid manual updates when discovery is authoritative")),
                new TableInfo("CI Relationship","cmdb_rel_ci","Relationship record between two configuration items.","↔","#7C6CFF",Arrays.asList("parent","child","type"),Arrays.asList("cmdb_ci"),Arrays.asList("Discovery","Service Mapping"),Arrays.asList("Relationship ACLs"),Arrays.asList("Use meaningful relationship types"))
        )));
        ms.add(new ModuleInfo("IT Operations Management","ITOM","◈","Operational visibility, event management, discovery and service context.","#4CC7F0",Arrays.asList(
                new TableInfo("Event","em_event","Operational event record received for processing.","!", "#4CC7F0",Arrays.asList("source","type","node","severity","description","message_key"),Arrays.asList("cmdb_ci","em_alert"),Arrays.asList("Event rules","Alert management"),Arrays.asList("Event ACLs"),Arrays.asList("Normalize sources and severities")),
                new TableInfo("Alert","em_alert","Normalized operational alert that can become actionable work.","A","#4CC7F0",Arrays.asList("number","severity","source","node","metric_name","state"),Arrays.asList("em_event","cmdb_ci","incident"),Arrays.asList("Alert correlation","Incident creation"),Arrays.asList("Operational ACLs"),Arrays.asList("Correlate noise before creating tickets"))
        )));
        ms.add(new ModuleInfo("IT Asset Management","ITAM","▣","Asset lifecycle, models, contracts and ownership.","#F4B25C",Arrays.asList(
                new TableInfo("Asset","alm_asset","Track the lifecycle, ownership and financial view of an asset.","A","#F4B25C",Arrays.asList("asset_tag","serial_number","model","assigned_to","stockroom","install_status","cost"),Arrays.asList("cmdb_ci","alm_hardware"),Arrays.asList("Asset flows","Inventory workflows"),Arrays.asList("Asset ACLs"),Arrays.asList("Keep asset and CI identity synchronized")),
                new TableInfo("Hardware Asset","alm_hardware","Hardware-specific asset extension.","H","#F4B25C",Arrays.asList("asset_tag","serial_number","model","warranty_expiration"),Arrays.asList("alm_asset","cmdb_ci"),Arrays.asList("Procurement","Lifecycle"),Arrays.asList("Asset ACLs"),Arrays.asList("Track disposal and warranty"))
        )));
        ms.add(new ModuleInfo("Customer Service Management","CSM","◌","Customer cases, accounts, contacts, interactions and entitlements.","#E56DA8",Arrays.asList(
                new TableInfo("Case","sn_customerservice_case","Customer service case used to manage a customer issue or request.","C","#E56DA8",Arrays.asList("number","account","contact","priority","state","assignment_group","short_description"),Arrays.asList("customer_account","customer_contact","interaction"),Arrays.asList("Case flows","Omnichannel","SLAs"),Arrays.asList("Customer criteria","ACLs"),Arrays.asList("Design customer visibility carefully")),
                new TableInfo("Account","customer_account","Customer organization record.","A","#E56DA8",Arrays.asList("name","number","industry","primary_contact"),Arrays.asList("customer_contact","case"),Arrays.asList("Account workflows"),Arrays.asList("Customer access controls"),Arrays.asList("Use account hierarchy deliberately"))
        )));
        ms.add(new ModuleInfo("Human Resources Service Delivery","HRSD","♡","Employee cases, HR profiles and lifecycle processes.","#8D7BFF",Arrays.asList(
                new TableInfo("HR Case","sn_hr_core_case","Employee HR case record.","H","#8D7BFF",Arrays.asList("number","opened_for","hr_service","assignment_group","state","short_description"),Arrays.asList("sn_hr_core_profile","sys_user"),Arrays.asList("Lifecycle flows","HR approvals"),Arrays.asList("Strict HR ACLs","User criteria"),Arrays.asList("Least privilege is essential")),
                new TableInfo("HR Profile","sn_hr_core_profile","HR-specific employee profile data.","P","#8D7BFF",Arrays.asList("user","department","location","manager"),Arrays.asList("sys_user"),Arrays.asList("HR profile sync"),Arrays.asList("Sensitive data ACLs"),Arrays.asList("Minimize sensitive field exposure"))
        )));
        ms.add(new ModuleInfo("Security Operations","SecOps","⚡","Security incidents, vulnerabilities and response orchestration.","#EF767A",Arrays.asList(
                new TableInfo("Security Incident","sn_si_incident","Security incident record for response and investigation.","!", "#EF767A",Arrays.asList("number","severity","state","assigned_to","assignment_group","description"),Arrays.asList("sys_user","sys_user_group"),Arrays.asList("Security flows","Integrations"),Arrays.asList("Strict ACLs"),Arrays.asList("Control access to sensitive evidence")),
                new TableInfo("Vulnerable Item","sn_vul_vulnerable_item","Tracks a vulnerable configuration item and remediation context.","V","#EF767A",Arrays.asList("number","vulnerability","cmdb_ci","risk_rating","state"),Arrays.asList("cmdb_ci","sys_user_group"),Arrays.asList("Vulnerability response"),Arrays.asList("Security ACLs"),Arrays.asList("Tie remediation to CI ownership"))
        )));
        ms.add(new ModuleInfo("Strategic Portfolio Management","SPM","◆","Demands, projects, resources, ideas and portfolio decisions.","#45C8A2",Arrays.asList(
                new TableInfo("Demand","dmn_demand","Evaluate proposed work before commitment.","D","#45C8A2",Arrays.asList("number","short_description","state","business_case","priority"),Arrays.asList("pm_project","idea"),Arrays.asList("Demand workflow","Approvals"),Arrays.asList("Portfolio ACLs"),Arrays.asList("Tie demand to strategic outcome")),
                new TableInfo("Project","pm_project","Plan and track an approved body of work.","P","#45C8A2",Arrays.asList("number","short_description","state","start_date","end_date","project_manager"),Arrays.asList("pm_project_task","sys_user"),Arrays.asList("Project automation"),Arrays.asList("Project ACLs"),Arrays.asList("Keep project and task states aligned"))
        )));
        ms.add(new ModuleInfo("Field Service Management","FSM","⌁","Work orders, work tasks, agents and dispatch.","#F09A5B",Arrays.asList(
                new TableInfo("Work Order","wm_order","Field work request and execution context.","W","#F09A5B",Arrays.asList("number","state","assigned_to","location","planned_start"),Arrays.asList("wm_task","cmdb_ci"),Arrays.asList("Dispatch","Mobile flows"),Arrays.asList("Work order ACLs"),Arrays.asList("Optimize for technician experience")),
                new TableInfo("Work Order Task","wm_task","Execution task under a work order.","T","#F09A5B",Arrays.asList("number","work_order","state","assigned_to"),Arrays.asList("wm_order","wm_agent"),Arrays.asList("Dispatch"),Arrays.asList("Task ACLs"),Arrays.asList("Keep task status accurate"))
        )));
        ms.add(new ModuleInfo("Governance, Risk & Compliance","GRC","✓","Risk, controls, policies and evidence.","#A7B45E",Arrays.asList(
                new TableInfo("Risk","sn_risk_risk","Risk record capturing a threat or exposure.","R","#A7B45E",Arrays.asList("number","statement","owner","rating","state"),Arrays.asList("sn_compliance_control"),Arrays.asList("Risk workflows"),Arrays.asList("GRC ACLs"),Arrays.asList("Maintain traceable ownership")),
                new TableInfo("Control","sn_compliance_control","Control requirement and assessment context.","C","#A7B45E",Arrays.asList("number","statement","owner","state"),Arrays.asList("sn_risk_risk","sn_compliance_policy"),Arrays.asList("Assessments","Evidence"),Arrays.asList("GRC ACLs"),Arrays.asList("Link controls to risks"))
        )));
        ms.add(new ModuleInfo("Application Development","Platform","⌘","Scoped apps, scripts, data model, security and testing.","#4B7BFF",new ArrayList<>()));
        ms.add(new ModuleInfo("Integration & APIs","Integration","⇄","REST, imports, transforms, authentication and integration patterns.","#39C6A6",new ArrayList<>()));
        ms.add(new ModuleInfo("Automation & Platform","Automation","⚙","Flow Designer, events, notifications, scheduled automation and platform tooling.","#8D7BFF",new ArrayList<>()));
        return ms;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        density = getResources().getDisplayMetrics().density;

        // Make the window edge-to-edge on every API level and let our own insets
        // listener pad the header / bottom nav by the exact status-bar and
        // navigation-bar height. Apps targeting Android 15 (API 35) get edge-to-edge
        // forced on regardless of what the theme requests, so this is the fix for
        // the header text overlapping the status bar rather than an optional extra.
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.setSystemBarsAppearance(
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                        WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }

        modules=new ArrayList<>(buildModules());
        buildShell();
        showHome();
    }

    TextView tv(String s,float sp,int color){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color); v.setGravity(Gravity.CENTER_VERTICAL); return v;
    }

    GradientDrawable bg(int color,float rDp){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(rDp*density); return g; }
    GradientDrawable stroke(int fill,int line,float rDp){ GradientDrawable g=bg(fill,rDp); g.setStroke(1,line); return g; }

    void buildShell(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        // Soft vertical gradient instead of a flat fill — a cheap, reliable way to get
        // some depth behind the glass cards without needing a real-time blur.
        GradientDrawable rootBg=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{Color.rgb(239,244,255), bg});
        root.setBackground(rootBg);

        top=new LinearLayout(this); top.setOrientation(LinearLayout.VERTICAL);
        topBasePadTop = dp(14);
        top.setPadding(dp(18), topBasePadTop, dp(18), dp(8));

        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView mark=tv("SN",11,Color.WHITE); mark.setGravity(Gravity.CENTER); mark.setTypeface(null,1); mark.setBackground(bg(blue,20));
        brand.addView(mark,new LinearLayout.LayoutParams(dp(34),dp(34)));
        TextView app=tv("  SnowEdge Consultancy",16,text); app.setTypeface(null,1);
        LinearLayout.LayoutParams appLp=new LinearLayout.LayoutParams(0,dp(34),1); appLp.leftMargin=dp(10);
        brand.addView(app,appLp);
        TextView menu=tv("⋮",22,muted); menu.setGravity(Gravity.CENTER); menu.setOnClickListener(v->showAbout());
        brand.addView(menu,new LinearLayout.LayoutParams(dp(34),dp(34)));
        top.addView(brand);

        title=tv("",25,text); title.setTypeface(null,1); title.setPadding(0,dp(14),0,0); top.addView(title);
        subtitle=tv("",13,muted); subtitle.setPadding(0,dp(3),0,dp(9)); top.addView(subtitle);

        search=new EditText(this); search.setSingleLine(true); search.setHint("Search modules, tables, APIs, concepts…");
        search.setTextSize(14); search.setPadding(dp(18),0,dp(18),0);
        search.setBackground(stroke(Color.WHITE,Color.rgb(220,226,236),24));
        top.addView(search,new LinearLayout.LayoutParams(-1,dp(48)));
        search.setOnEditorActionListener((v,a,e)->{ doSearch(v.getText().toString()); return true;});
        root.addView(top,new LinearLayout.LayoutParams(-1,-2));

        ScrollView sc=new ScrollView(this); sc.setFillViewport(true);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(14),dp(6),dp(14),dp(28));
        sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));

        bottomNav=new LinearLayout(this); bottomNav.setGravity(Gravity.CENTER);
        bottomNavBasePadBottom = dp(10);
        bottomNav.setPadding(dp(8),dp(10),dp(8),bottomNavBasePadBottom);
        bottomNav.setBackground(bg(Color.WHITE,0));
        bottomNav.setElevation(dp(8));
        root.addView(bottomNav,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);

        // Apply the real status-bar / navigation-bar insets on top of our base padding.
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int insetTop, insetBottom;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                insetTop = bars.top; insetBottom = bars.bottom;
            } else {
                insetTop = insets.getSystemWindowInsetTop();
                insetBottom = insets.getSystemWindowInsetBottom();
            }
            top.setPadding(top.getPaddingLeft(), topBasePadTop + insetTop, top.getPaddingRight(), top.getPaddingBottom());
            bottomNav.setPadding(bottomNav.getPaddingLeft(), bottomNav.getPaddingTop(), bottomNav.getPaddingRight(), bottomNavBasePadBottom + insetBottom);
            return insets;
        });

        root.setAlpha(0f); root.setScaleX(.985f); root.setScaleY(.985f);
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).start();
    }

    void showAbout(){
        String version = "";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            version = pi.versionName;
        } catch (Exception ignored) {}
        showDetailDialog("SnowEdge Consultancy","About this app",
                "A pocket ServiceNow reference for developers and admins — modules, tables, fields, "+
                "automation points, security notes and troubleshooting playbooks in one place.\n\n"+
                "Version "+version+"\n\nBuilt by SnowEdge Consultancy.");
    }

    void setHeader(String t,String s){
        title.setText(t); subtitle.setText(s);
    }

    void clear(){content.removeAllViews();}
    void addSpace(int hDp){Space sp=new Space(this); content.addView(sp,new LinearLayout.LayoutParams(dp(1),dp(hDp)));}

    TextView pill(String s,int color){
        TextView p=tv(s,10,color); p.setGravity(Gravity.CENTER); p.setTypeface(null,1);
        p.setPadding(dp(12),dp(4),dp(12),dp(4));
        p.setBackground(bg(Color.argb(18, color>>16 &255, color>>8&255, color&255),30));
        return p;
    }

    void addSection(String s){
        TextView v=tv(s.toUpperCase(Locale.US),10,muted); v.setTypeface(null,1); v.setPadding(dp(4),dp(20),dp(4),dp(9)); content.addView(v);
    }

    LinearLayout tile(String icon,String name,String meta,int color,View.OnClickListener onClick){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14),dp(14),dp(12),dp(14));
        card.setBackground(stroke(Color.argb(235,255,255,255),Color.rgb(225,230,239),24));
        card.setElevation(dp(1));
        card.setOnClickListener(onClick);
        TextView ic=tv(icon,22,color); ic.setGravity(Gravity.CENTER); ic.setBackground(bg(Color.rgb(243,246,252),18));
        card.addView(ic,new LinearLayout.LayoutParams(dp(46),dp(46)));
        TextView n=tv(name,15,text); n.setTypeface(null,1); n.setPadding(0,dp(10),0,dp(3)); n.setMaxLines(3); card.addView(n,new LinearLayout.LayoutParams(-1,-2));
        TextView m=tv(meta,11,muted); m.setMaxLines(3); card.addView(m,new LinearLayout.LayoutParams(-1,-2));
        return card;
    }

    void gridTile(String icon,String name,String meta,int color,View.OnClickListener click){
        if (content.getChildCount()==0 || !(content.getChildAt(content.getChildCount()-1) instanceof LinearLayout) || !"GRID".equals(content.getChildAt(content.getChildCount()-1).getTag())) {
            LinearLayout row=new LinearLayout(this); row.setTag("GRID"); row.setPadding(0,0,0,dp(10)); content.addView(row,new LinearLayout.LayoutParams(-1,-2));
        }
        LinearLayout row=(LinearLayout)content.getChildAt(content.getChildCount()-1);
        if(row.getChildCount()>=2){
            row=new LinearLayout(this); row.setTag("GRID"); row.setPadding(0,0,0,dp(10)); content.addView(row,new LinearLayout.LayoutParams(-1,-2));
        }
        LinearLayout t=tile(icon,name,meta,color,click);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); if(row.getChildCount()>0) lp.leftMargin=dp(7); row.addView(t,lp);
    }

    void showBottom(String active){
        bottomNav.removeAllViews();
        nav("⌂","Home","home".equals(active),(v)->showHome());
        nav("▦","Explore","explore".equals(active),(v)->showModules());
        nav("▣","Learn","learn".equals(active),(v)->showLearn());
        nav("⌘","Dev","dev".equals(active),(v)->showDev());
    }
    void nav(String icon,String label,boolean active,View.OnClickListener l){
        LinearLayout n=new LinearLayout(this); n.setOrientation(LinearLayout.VERTICAL); n.setGravity(Gravity.CENTER);
        n.setPadding(dp(4),dp(4),dp(4),dp(2)); n.setOnClickListener(l);
        if(active){ n.setBackground(bg(Color.argb(20, blue>>16&255, blue>>8&255, blue&255),16)); }
        TextView i=tv(icon,19,active?blue:muted); i.setGravity(Gravity.CENTER); n.addView(i,new LinearLayout.LayoutParams(-1,dp(28)));
        TextView t=tv(label,9,active?blue:muted); t.setGravity(Gravity.CENTER); n.addView(t,new LinearLayout.LayoutParams(-1,dp(20)));
        bottomNav.addView(n,new LinearLayout.LayoutParams(0,-1,1));
    }

    void showHome(){
        backStack.clear(); clear(); setHeader("Learn ServiceNow.","Your mobile developer companion."); showBottom("home");
        addSection("Quick start");
        gridTile("▦","ITSM","Tables & workflows",blue,(v)->showModule(modules.get(0)));
        gridTile("⌘","CMDB","CIs & relationships",Color.rgb(124,108,255),(v)->showModule(modules.get(1)));
        gridTile("◈","ITOM","Events & services",Color.rgb(76,199,240),(v)->showModule(modules.get(2)));
        gridTile("⚙","Developer","Scripts & platform",Color.rgb(57,198,166),(v)->showDev());
        addSection("Popular");
        addWide("Incident","incident","⚠","Table deep dive",blue,(v)->showTable(incident(),modules.get(0)));
        addWide("Change Request","change_request","⇄","Approvals, risk & implementation",blue,(v)->showTable(itsmTables().get(4),modules.get(0)));
        addWide("Configuration Item","cmdb_ci","C","CMDB foundation",Color.rgb(124,108,255),(v)->showTable(modules.get(1).tables.get(0),modules.get(1)));
        addSection("All modules");
        gridTile("▣","Browse all","10 product areas",lilac,(v)->showModules());
        gridTile("?","Quick quiz","5 questions",Color.rgb(57,198,166),(v)->showQuiz(incident()));
    }

    void addWide(String name,String table,String icon,String meta,int color,View.OnClickListener l){
        LinearLayout row=new LinearLayout(this); row.setPadding(dp(12),dp(11),dp(10),dp(11)); row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(stroke(Color.argb(235,255,255,255),Color.rgb(225,230,239),22));
        row.setElevation(dp(1));
        row.setOnClickListener(l);
        TextView ic=tv(icon,18,color); ic.setGravity(Gravity.CENTER); ic.setBackground(bg(Color.rgb(243,246,252),18));
        row.addView(ic,new LinearLayout.LayoutParams(dp(44),dp(44)));
        LinearLayout mid=new LinearLayout(this); mid.setOrientation(LinearLayout.VERTICAL); mid.setPadding(dp(12),0,dp(8),0);
        TextView n=tv(name,15,text); n.setTypeface(null,1); n.setMaxLines(4); mid.addView(n,new LinearLayout.LayoutParams(-1,-2));
        TextView m=tv(meta+"  •  "+table,10,muted); m.setMaxLines(4); m.setPadding(0,dp(3),0,0); mid.addView(m,new LinearLayout.LayoutParams(-1,-2));
        row.addView(mid,new LinearLayout.LayoutParams(0,-2,1));
        TextView a=tv("›",24,muted); a.setGravity(Gravity.CENTER); row.addView(a,new LinearLayout.LayoutParams(dp(26),dp(44)));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(9); content.addView(row,lp);
    }

    void showModules(){
        clear(); setHeader("ServiceNow map","Choose a product area, then drill into its tables."); showBottom("explore"); search.setText("");
        addSection("Product areas");
        for(ModuleInfo m:modules){
            gridTile(m.icon,m.label,m.code,Color.parseColor(m.accent),(v)->showModule(m));
        }
    }

    void showModule(ModuleInfo m){
        clear(); setHeader(m.label,m.blurb); showBottom("explore");
        addBack("‹  "+m.label,(v)->showModules());
        addSection("Explore");
        gridTile("▦","Tables",m.tables.size()+" known tables",Color.parseColor(m.accent),(v)->showTables(m));
        gridTile("⌘","Developer","APIs & scripting",blue,(v)->showDev());
        gridTile("◇","Architecture","Design notes",Color.parseColor(m.accent),(v)->showArchitecture(m));
        gridTile("✓","Security","Roles & ACLs",Color.rgb(232,102,110),(v)->showSecurity(m));
        addSection("Recommended");
        int limit=Math.min(m.tables.size(),4);
        for(int i=0;i<limit;i++){ TableInfo table=m.tables.get(i); addWide(table.label,table.name,table.icon,"Open table details",Color.parseColor(table.color),(v)->showTable(table,m)); }
        if(m.tables.isEmpty()){
            addWide("Coming next","knowledge","•","Module framework is ready; table catalog can be expanded.",Color.parseColor(m.accent),(v)->showToast("This module is ready for more curated content."));
        }
    }

    void addBack(String text,View.OnClickListener click){
        TextView b=tv(text,13,blue); b.setTypeface(null,1); b.setPadding(dp(3),dp(4),dp(3),dp(10)); b.setOnClickListener(click); content.addView(b);
    }

    void showTables(ModuleInfo m){
        clear(); setHeader(m.label+" tables","Search, browse and open a table for a deep dive."); showBottom("explore");
        addBack("‹  "+m.label,(v)->showModule(m));
        final EditText filter=new EditText(this); filter.setSingleLine(true); filter.setHint("Filter tables, e.g. incident, sla, request…");
        filter.setTextSize(13); filter.setPadding(dp(16),0,dp(16),0);
        filter.setBackground(stroke(Color.WHITE,Color.rgb(220,226,236),24));
        content.addView(filter,new LinearLayout.LayoutParams(-1,dp(46)));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); content.addView(list);
        Runnable render=()->{
            list.removeAllViews();
            String q=filter.getText().toString().toLowerCase(Locale.US);
            for(TableInfo t:m.tables){
                if(q.isEmpty() || (t.label+" "+t.name+" "+t.desc).toLowerCase(Locale.US).contains(q)){
                    LinearLayout row=tile(t.icon,t.label,t.name,Color.parseColor(t.color),v->showTable(t,m));
                    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(10); list.addView(row,lp);
                }
            }
        };
        filter.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){}public void onTextChanged(CharSequence s,int a,int b,int c){render.run();}public void afterTextChanged(android.text.Editable e){}});
        render.run();
    }

    void showIncidentDeepDive(ModuleInfo m){
        clear(); setHeader("Incident","incident"); showBottom("explore");
        addBack("‹  ITSM tables",(v)->showTables(m));

        LinearLayout hero=new LinearLayout(this);
        hero.setPadding(dp(16),dp(16),dp(16),dp(16));
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setBackground(bg(Color.rgb(237,242,255),24));
        TextView tag=tv("TABLE DEEP DIVE · CORE ITSM",10,blue); tag.setTypeface(null,1); hero.addView(tag);
        TextView nm=tv("Incident",27,text); nm.setTypeface(null,1); hero.addView(nm);
        TextView tn=tv("incident  ·  extends task",11,blue); hero.addView(tn);
        TextView d=tv("Use Incident to restore normal service quickly while minimizing business impact. This developer-oriented reference covers data, security, automation and troubleshooting.",13,muted);
        d.setPadding(0,dp(8),0,0); hero.addView(d);
        content.addView(hero);

        addSection("Lifecycle");
        addWide("New → In Progress → On Hold → Resolved → Closed","state","↻","Understand state transitions and who is allowed to move them.",blue,(v)->showToast("State logic belongs on the server; pair UX controls with server-side enforcement."));
        addWide("Priority = Impact × Urgency","priority","!","Use consistent priority calculation and validation.",lilac,(v)->showToast("Check impact and urgency when troubleshooting priority."));
        addWide("Assignment","assignment_group / assigned_to","G","Route work to the correct ownership model.",Color.rgb(57,198,166),(v)->showToast("Review assignment rules, group membership and manual overrides."));

        addSection("Field dictionary");
        String[][] fields={
            {"number","Auto-number","Unique incident identifier"},
            {"caller_id","Reference → sys_user","Person reporting or affected by the incident"},
            {"category","Choice","High-level classification"},
            {"service","Service context","Business or technical service context"},
            {"cmdb_ci","Reference → CMDB CI","Affected configuration item"},
            {"impact","Choice","Business impact"},
            {"urgency","Choice","Time sensitivity"},
            {"priority","Choice","Overall prioritization"},
            {"assignment_group","Reference → sys_user_group","Owning team"},
            {"assigned_to","Reference → sys_user","Individual assignee"},
            {"short_description","String","Concise incident summary"},
            {"description","Text","Detailed incident description"},
            {"work_notes","Journal","Internal collaboration"},
            {"comments","Journal","Customer-visible collaboration depending on configuration"},
            {"close_code","Choice","Resolution classification"},
            {"close_notes","Journal","Resolution summary"}
        };
        for(String[] f:fields) addWide(f[0],f[1],"•",f[2],blue,(v)->showDetailDialog(f[0],f[1],f[2]+"\n\nIncident field: "+f[0]+"\nType / relationship: "+f[1]));

        addSection("Data model");
        addWide("task","task","↑","Incident inherits common task behavior and fields.",Color.rgb(124,108,255),(v)->showToast("Incident is task-based; inspect inherited fields before customizing."));
        addWide("cmdb_ci","cmdb_ci","◇","Reference to the affected configuration item.",Color.rgb(124,108,255),(v)->showToast("Use CMDB context to connect incidents to affected CIs."));
        addWide("task_sla","task_sla","⏱","Task-level SLA timing and breach records.",Color.rgb(57,198,166),(v)->showToast("Check task_sla when troubleshooting SLA timing."));

        addSection("Developer toolkit");
        addWide("GlideRecord","server-side","⌘","Query and update incident records safely.",blue,(v)->showToast("Use GlideRecord for server-side record operations; validate inputs and avoid unnecessary queries."));
        addWide("Business Rules","server-side","⚙","Enforce lifecycle, data and automation behavior.",lilac,(v)->showToast("Keep rules focused and avoid expensive or recursive updates."));
        addWide("Client Scripts","client-side","◌","Improve form UX and guide data entry.",Color.rgb(57,198,166),(v)->showToast("Client Scripts are not a security boundary."));
        addWide("UI Policies","client-side","◇","Control mandatory, visible and read-only behavior on forms.",blue,(v)->showToast("Use UI Policies for UX; enforce critical requirements server-side."));
        addWide("UI Actions","form/list","→","Expose controlled actions such as Resolve or Reopen.",lilac,(v)->showToast("Secure UI Actions with conditions and server-side validation."));
        addWide("Flow Designer","automation","⚡","Orchestrate notifications, tasks and integrations.",Color.rgb(57,198,166),(v)->showToast("Prefer maintainable Flow Designer automation when the use case fits."));

        addSection("Security");
        addWide("Table ACL","incident","✓","Controls record access.",Color.rgb(232,102,110),(v)->showToast("Check table ACLs when users cannot read or write incidents."));
        addWide("Field ACL","incident.<field>","✓","Controls sensitive field access.",Color.rgb(232,102,110),(v)->showToast("Field ACLs can restrict values even when the record is visible."));
        addWide("Server-side validation","Business Rules / Data Policies","✓","Never trust client-side controls for authorization.",Color.rgb(232,102,110),(v)->showToast("Security must be enforced on the server."));

        addSection("Troubleshooting playbook");
        addWide("User cannot see Incident","ACL / role / query","?","Check table ACL, field ACL, roles and data restrictions.",blue,(v)->showToast("Start with ACL debugging and impersonation."));
        addWide("Assignment is wrong","Assignment rules / BR / Flow","?","Trace which automation last changed assignment_group or assigned_to.",lilac,(v)->showToast("Inspect Business Rules, assignment rules and Flow execution details."));
        addWide("SLA not running","SLA definition / conditions","?","Validate start condition, schedule, task state and matching SLA.",Color.rgb(57,198,166),(v)->showToast("Inspect task_sla and the SLA definition."));
        addWide("Priority unexpected","Impact / Urgency / automation","?","Check priority calculation and custom automation.",blue,(v)->showToast("Compare impact and urgency with configured priority logic."));
        addWide("Notification missing","Event / notification / condition","?","Check event generation, notification conditions and recipients.",lilac,(v)->showToast("Trace the event and notification execution path."));

        addSection("Real-world scenarios");
        addWide("Auto-route by CI support group","Incident + CMDB","Case","When a CI is selected, route the incident to the CI support group.",Color.rgb(57,198,166),(v)->showToast("Pattern: CI reference → derive ownership → validate group → assign."));
        addWide("Mandatory closure evidence","Incident state","Case","Require close code and close notes before resolution/closure.",blue,(v)->showToast("Use UI behavior for guidance plus server-side enforcement."));
        addWide("Major incident escalation","Incident priority","Case","Promote qualifying incidents into a coordinated major incident process.",Color.rgb(232,102,110),(v)->showToast("Define objective entry criteria and communication ownership."));

        addSection("Self-test");
        gridTile("?","Incident quiz","Test your knowledge",blue,(v)->showQuiz(incident()));
        gridTile("★","Interview mode","Scenario questions",lilac,(v)->showToast("Explain the Incident data model, security and automation choices."));
    }

    void showTable(TableInfo t,ModuleInfo m){
        if ("incident".equals(t.name)) { showIncidentDeepDive(m); return; }
        clear(); setHeader(t.label,t.name); showBottom("explore");
        addBack("‹  "+m.label+" tables",(v)->showTables(m));
        LinearLayout hero=new LinearLayout(this); hero.setPadding(dp(16),dp(16),dp(16),dp(16)); hero.setOrientation(LinearLayout.VERTICAL); hero.setBackground(bg(Color.rgb(237,242,255),24));
        TextView tag=tv("TABLE DEEP DIVE",10,blue); tag.setTypeface(null,1); hero.addView(tag);
        TextView nm=tv(t.label,25,text); nm.setTypeface(null,1); hero.addView(nm);
        TextView tn=tv(t.name,11,blue); hero.addView(tn);
        TextView d=tv(t.desc,13,muted); d.setPadding(0,dp(8),0,0); hero.addView(d);
        content.addView(hero);
        addSection("Key fields");
        for(String f:t.fields) addChip(f);
        addSection("Related tables");
        for(String r:t.related) addWide(r,r,"↔","Reference / relationship",Color.rgb(124,108,255),(v)->showDetailDialog(r,"Related table","This table is related to "+t.label+" through the ServiceNow data model.\n\nUse this relationship when tracing references, inheritance, automation or troubleshooting records."));
        addSection("Automation & process");
        for(String a:t.automation) addWide(a,"automation","⚙","Where it typically fits",Color.rgb(57,198,166),(v)->showDetailDialog("Automation & process", "Where it fits", a+"\n\nReview the specific Business Rule, Flow, event, notification or SLA configuration before changing behavior."));
        addSection("Security");
        for(String s:t.security) addWide(s,"security","✓","Control point",Color.rgb(232,102,110),(v)->showDetailDialog("Security control", "Security", s+"\n\nTreat client-side controls as user experience only. Enforce authorization and sensitive data access on the server."));
        addSection("Developer tips");
        for(String tip:t.tips) addWide(tip,"best-practice","★","Practical guidance",blue,(v)->showDetailDialog("Developer tip", "Best practice", tip+"\n\nApply this principle consistently and verify the impact in a safe development environment."));
        addSection("Next level");
        gridTile("?", "Test yourself", "Table quiz", blue, (v)->showQuiz(t));
        gridTile("⌘", "Script patterns", "Glide / client / flow", lilac, (v)->showToast("Script patterns can be added to this table card."));
    }

    void addChip(String s){
        TextView c=tv(s,10,text); c.setGravity(Gravity.CENTER); c.setPadding(dp(12),dp(7),dp(12),dp(7)); c.setBackground(bg(Color.WHITE,20));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(34)); lp.rightMargin=dp(7); lp.bottomMargin=dp(7);
        LinearLayout row;
        if(content.getChildCount()==0 || !(content.getChildAt(content.getChildCount()-1) instanceof LinearLayout) || !"CHIPS".equals(content.getChildAt(content.getChildCount()-1).getTag())){
            row=new LinearLayout(this); row.setTag("CHIPS"); row.setPadding(0,0,0,dp(3)); content.addView(row,new LinearLayout.LayoutParams(-1,-2));
        } else row=(LinearLayout)content.getChildAt(content.getChildCount()-1);
        row.addView(c,lp);
    }

    void showArchitecture(ModuleInfo m){
        clear(); setHeader("Architecture","How to think about "+m.label+"."); showBottom("explore"); addBack("‹  "+m.label,(v)->showModule(m));
        addSection("Architecture lens");
        addWide("Data model","references","◇","Choose standard tables before creating custom ones.",blue,(v)->showToast("Prefer OOTB data models where they fit."));
        addWide("Security model","acl","✓","Design roles, ACLs and data boundaries early.",Color.rgb(232,102,110),(v)->showToast("Security belongs in the design, not after development."));
        addWide("Automation","flow","⚙","Use Flow Designer where it keeps logic maintainable.",lilac,(v)->showToast("Keep custom script focused."));
        addWide("Observability","logs","◌","Plan logs, errors and operational visibility.",Color.rgb(57,198,166),(v)->showToast("Build for supportability."));
    }

    void showSecurity(ModuleInfo m){ showArchitecture(m); title.setText("Security"); subtitle.setText("Roles, ACLs, criteria and least privilege."); }

    void showDev(){
        clear(); setHeader("Developer desk","Reference common platform concepts."); showBottom("dev");
        addSection("Core concepts");
        for(String s:devConcepts) addWide(s,s.toLowerCase(Locale.US).replace(" ","_"),"⌘","Open practical guidance",blue,(v)->showToast(s+" reference opened."));
        addSection("Practice");
        gridTile("?","Quiz me","Developer knowledge check",lilac,(v)->showLearn());
        gridTile("✓","Best practices","Patterns to reuse",Color.rgb(57,198,166),(v)->showToast("Best-practice library coming into the next content pass."));
    }

    void showLearn(){
        clear(); setHeader("Learn","Small challenges, big ServiceNow skills."); showBottom("learn");
        addSection("Learning path");
        String[][] x={{"01","Platform foundations","Tables, applications, scopes"},{"02","Scripting","Client vs server, Glide APIs"},{"03","Automation","Flow Designer, events, scheduled work"},{"04","Security","Roles, ACLs and boundaries"},{"05","Integrations","REST, imports, transforms"},{"06","Architecture","Data model, performance, CSDM"}};
        for(String[] a:x) addWide(a[0]+"  "+a[1],a[1].toLowerCase(Locale.US),"▣",a[2],blue,(v)->showToast("Learning module: "+a[1]));
        addSection("Self test");
        gridTile("?","5-question quiz","ACLs, APIs, data model",blue,(v)->showQuiz(incident()));
    }

    void showQuiz(TableInfo t){
        clear(); setHeader("Quick quiz","Test yourself on "+t.label+"."); showBottom("learn");
        addBack("‹  "+t.label,(v)->showTable(t,modules.get(0)));
        addSection("Question");
        addWide("Why is server-side security important?","q1","?","Because client-side controls can be bypassed.",blue,(v)->showToast("Exactly — enforce authorization on the server."));
        addWide("What API queries records server-side?","q2","⌘","GlideRecord",lilac,(v)->showToast("Correct: GlideRecord."));
        addWide("What should an incident capture?","q3","✓","Impact, urgency, priority, ownership and closure data.",Color.rgb(57,198,166),(v)->showToast("Good answer."));
    }

    void doSearch(String q){
        q=q==null?"":q.trim().toLowerCase(Locale.US);
        if(q.isEmpty()){showHome();return;}
        clear(); setHeader("Search","Results for “"+q+"”"); showBottom("home");
        addSection("Matches");
        int count=0;
        for(ModuleInfo m:modules){
            if((m.label+" "+m.code+" "+m.blurb).toLowerCase(Locale.US).contains(q)){
                addWide(m.label,m.code,m.icon,m.blurb,Color.parseColor(m.accent),(v)->showModule(m)); count++;
            }
            for(TableInfo t:m.tables){
                if((t.label+" "+t.name+" "+t.desc).toLowerCase(Locale.US).contains(q)){
                    addWide(t.label,t.name,t.icon,"Table deep dive",Color.parseColor(t.color),(v)->showTable(t,m)); count++;
                }
            }
        }
        for(String s:devConcepts) if(s.toLowerCase(Locale.US).contains(q)){ addWide(s,"developer","⌘","Developer reference",blue,(v)->showToast("Opened "+s)); count++; }
        if(count==0){ TextView empty=tv("No results yet. Try “incident”, “sla”, “cmdb”, “GlideRecord” or “ACL”.",14,muted); empty.setPadding(dp(10),dp(30),dp(10),dp(30)); content.addView(empty); }
    }

    void showToast(String s){
        if(s==null) return;
        if(s.length()>70) showDetailDialog("Details","ServiceNow reference",s);
        else Toast.makeText(this,s,Toast.LENGTH_LONG).show();
    }

    void showDetailDialog(String heading,String subheading,String body){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(24),dp(20),dp(24),dp(8));
        TextView h=tv(heading,22,text); h.setTypeface(null,1); h.setPadding(0,0,0,dp(4)); box.addView(h,new LinearLayout.LayoutParams(-1,-2));
        if(subheading!=null && !subheading.isEmpty()){ TextView sub=tv(subheading,12,blue); sub.setTypeface(null,1); sub.setPadding(0,0,0,dp(14)); box.addView(sub,new LinearLayout.LayoutParams(-1,-2)); }
        ScrollView sv=new ScrollView(this);
        TextView b=tv(body==null?"":body,15,muted); b.setGravity(Gravity.TOP); b.setLineSpacing(0,1.15f);
        sv.addView(b,new ScrollView.LayoutParams(-1,-2)); box.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        AlertDialog dlg=new AlertDialog.Builder(this).setView(box).setPositiveButton("Close",null).create();
        dlg.show();
        Window w=dlg.getWindow();
        if(w!=null){ w.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.92f), (int)(getResources().getDisplayMetrics().heightPixels*0.72f)); }
    }

    @Override public void onBackPressed(){
        showHome();
    }
}
