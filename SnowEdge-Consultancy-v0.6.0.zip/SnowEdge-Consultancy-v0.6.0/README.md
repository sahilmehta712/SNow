# SnowEdge Consultancy
(packaged as `SnowEdge-Consultancy-v0.6.0.zip` to match the existing CI workflow · app versionName bumped to 0.6.1 internally)

Mobile-first offline ServiceNow developer companion — modules, tables, fields,
automation points, security notes and troubleshooting playbooks, all bundled
into a single native Android app (no server, no login).

Navigation: Home → ITSM → Tables → Incident → Incident deep dive, plus a
full module map, a Developer desk, a Learn track, and search across all of it.

## v0.6.1 — responsiveness fix + polish
The previous build (v0.6.0) rendered fine on some screens but overlapped
text on others — the header could clip under the status bar, and rows felt
cramped. Root causes and fixes:

- **Pixel vs. dp bug (main cause).** Every padding/size/margin in the UI was
  a raw pixel literal instead of a density-independent `dp` value. On
  higher-density phones that made containers far too small for the text
  inside them, which is what read as "overlapping." All of it now goes
  through a `dp()` helper that scales by the screen's actual density.
- **Edge-to-edge on Android 15.** This app targets SDK 35, where the OS
  forces edge-to-edge layout and ignores `setStatusBarColor`/
  `setNavigationBarColor` — so on an Android 15 device the header could draw
  under the status bar with nothing pushing it down. Fixed with a proper
  `WindowInsets` listener that pads the header and bottom nav by the real
  system-bar height, on every API level from 26 up.
- `minSdk` lowered from 34 to 26 — no functional change on Android 14/15,
  just broader device support.
- The bottom nav now uses a subtle elevated card + a pill highlight behind
  the active tab; module/table rows and cards got a touch more elevation and
  slightly larger tap targets for a cleaner, more "glass" feel.
- The `⋮` menu button (previously decorative) now opens an About dialog.
- Ten of the ITSM tables (Service Offering, SLA Definition, Assignment
  Group, User, Journal Entry, Incident Metric, Major Incident, Service,
  Incident Alert, Incident Child) had identical placeholder field/automation/
  security text copy-pasted across all of them — each now has real, distinct
  ServiceNow detail.

Android 8.0+ (minSdk 26), target/compile SDK 35, Gradle 8.9.

## Building
Push this zip through your existing GitHub Actions workflow (`gradle
assembleDebug`), or open it in Android Studio and hit Run. No new
dependencies were added — it's still a single Activity with zero external
libraries, so nothing extra needs to resolve.
