# SnowEdge Consultancy — ServiceNow Developer Companion v0.2

A lightweight offline Android 14+ learning/reference app.

## What is included

- SnowEdge Consultancy branding with an SN developer-themed icon
- Animated startup
- Explore: ServiceNow product/module map and important tables
- Global search across modules, tables, developer concepts and reference content
- Learn: structured learning path and daily challenge
- Developer Desk: scripting, security, automation, architecture and integration references
- Saved workspace placeholder for future favorites
- Offline/static data; no login, analytics, backend or network dependency
- No third-party Android libraries

## Build

Requires JDK 17 and Gradle 8.7+.

```bash
gradle assembleDebug
```

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Product scope

The app is an educational reference, not an exhaustive dump of every ServiceNow table. Names and availability can vary by release, installed plugins, scope and customer customization.

The learning structure is informed by ServiceNow's official developer learning material covering platform navigation, tables, scripting, security, events, email, imports, Flow Designer and Scripted REST APIs.
