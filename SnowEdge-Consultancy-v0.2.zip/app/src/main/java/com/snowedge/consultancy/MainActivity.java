package com.snowedge.consultancy;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    SnowView snowView;
    EditText search;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,16,24));
        getWindow().setNavigationBarColor(Color.rgb(7,16,24));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7,16,24));

        snowView = new SnowView(this);
        root.addView(snowView, new LinearLayout.LayoutParams(-1, 0, 1));

        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Search modules, tables, APIs, concepts...");
        search.setTextColor(Color.rgb(243,247,251));
        search.setHintTextColor(Color.rgb(130,148,164));
        search.setTextSize(15);
        search.setPadding(44, 0, 20, 0);
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(Color.rgb(17,28,39));
        gd.setCornerRadius(48);
        gd.setStroke(1, Color.rgb(62,84,103));
        search.setBackground(gd);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 54);
        sp.setMargins(22, 0, 22, 12);
        root.addView(search, sp);

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(10, 8, 10, 10);
        nav.setBackgroundColor(Color.rgb(10,20,29));
        String[] tabs = {"⌂\nExplore","▣\nLearn","⌘\nDev","★\nSaved"};
        for (int i=0;i<tabs.length;i++) {
            final int idx=i;
            TextView t = new TextView(this);
            t.setText(tabs[i]);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(11);
            t.setTextColor(Color.rgb(145,163,179));
            t.setPadding(8, 4, 8, 4);
            nav.addView(t, new LinearLayout.LayoutParams(0, 58, 1));
            t.setOnClickListener(v -> { snowView.page = idx; snowView.selected = -1; snowView.invalidate(); });
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, 76));

        setContentView(root);

        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ snowView.query=s.toString(); snowView.invalidate(); }
            public void afterTextChanged(android.text.Editable e){}
        });

        ObjectAnimator a = ObjectAnimator.ofFloat(snowView, View.ALPHA, 0f, 1f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(snowView, View.SCALE_X, .985f, 1f);
        ObjectAnimator sz = ObjectAnimator.ofFloat(snowView, View.SCALE_Y, .985f, 1f);
        AnimatorSet set = new AnimatorSet();
        set.playTogether(a,sy,sz); set.setDuration(520); set.start();
    }

    void openSearch() { search.requestFocus(); ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(search, InputMethodManager.SHOW_IMPLICIT); }

    class SnowView extends View {
        Paint p=new Paint(3); String query=""; int page=0, selected=-1; float scroll=0, downY;
        ArrayList<Module> modules = new ArrayList<>();
        ArrayList<Concept> concepts = new ArrayList<>();
        ArrayList<Quiz> quizzes = new ArrayList<>(); int quizIndex=0; int quizSelected=-1; boolean quizMode=false;

        SnowView(Context c){ super(c); setLayerType(View.LAYER_TYPE_SOFTWARE,null); Data.seed(modules,concepts,quizzes); }

        void txt(Canvas c,String s,float x,float y,float size,int color,boolean bold){
            p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size); p.setTypeface(bold?Typeface.create("sans",Typeface.BOLD):Typeface.create("sans",Typeface.NORMAL));
            c.drawText(s,x,y,p);
        }
        void round(Canvas c,float l,float t,float r,float b,float rad,int color){
            p.setStyle(Paint.Style.FILL); p.setColor(color); c.drawRoundRect(l,t,r,b,rad,rad,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(1); p.setColor(Color.rgb(45,65,81)); c.drawRoundRect(l,t,r,b,rad,rad,p); p.setStyle(Paint.Style.FILL);
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); c.drawColor(Color.rgb(7,16,24));
            if(page==0) explore(c); else if(page==1) learn(c); else if(page==2) dev(c); else saved(c);
        }

        void header(Canvas c,String kicker,String title,String sub){
            txt(c,"SN",24,45,15,Color.rgb(7,16,24),true);
            p.setColor(Color.rgb(92,200,255)); c.drawCircle(40,38,18,p);
            p.setColor(Color.rgb(111,124,255)); c.drawCircle(40,38,13,p);
            txt(c,"SN",27,44,12,Color.rgb(7,16,24),true);
            txt(c,"SnowEdge Consultancy",70,36,17,Color.rgb(243,247,251),true);
            txt(c,kicker.toUpperCase(Locale.US),24,88,11,Color.rgb(92,200,255),true);
            txt(c,title,24,119,28,Color.rgb(243,247,251),true);
            txt(c,sub,24,145,14,Color.rgb(147,165,182),false);
        }

        void explore(Canvas c){
            header(c,"ServiceNow developer companion","Everything ServiceNow.","Learn the platform. Build better solutions.");
            int y=175;
            if(query.trim().length()>0){
                txt(c,"Search results",24,y,13,Color.rgb(147,165,182),true); y+=28;
                int shown=0;
                for(Module m:modules){
                    boolean match=m.name.toLowerCase().contains(query.toLowerCase()) || m.tag.toLowerCase().contains(query.toLowerCase());
                    for(String[] t:m.tables) if(t[0].toLowerCase().contains(query.toLowerCase())||t[1].toLowerCase().contains(query.toLowerCase())) match=true;
                    if(match){ card(c,m,y); y+=92; if(++shown>=6) break; }
                }
                if(shown<8){
                    for(Concept x:concepts){
                        if(x.title.toLowerCase().contains(query.toLowerCase()) || x.category.toLowerCase().contains(query.toLowerCase())){
                            round(c,18,y,getWidth()-18,y+72,18,Color.rgb(17,28,39));
                            txt(c,"DEVELOPER REFERENCE",34,y+24,10,Color.rgb(69,211,156),true);
                            txt(c,x.title,34,y+49,16,Color.rgb(243,247,251),true);
                            y+=82; if(++shown>=8) break;
                        }
                    }
                }
                if(shown==0) txt(c,"No matches. Try a table, API, module, or concept.",24,y,15,Color.rgb(147,165,182),false);
                return;
            }
            txt(c,"CORE MAP",24,y,11,Color.rgb(147,165,182),true); y+=22;
            if(selected>=0){
                detail(c,modules.get(selected),y); return;
            }
            for(int i=0;i<modules.size();i++){ card(c,modules.get(i),y); y+=92; }
        }

        void card(Canvas c,Module m,int y){
            round(c,18,y, getWidth()-18,y+78,24,Color.rgb(17,28,39));
            p.setColor(m.color); c.drawCircle(40,y+27,7,p);
            txt(c,m.name,60,y+30,17,Color.rgb(243,247,251),true);
            txt(c,m.tag+"  •  "+m.tables.length+" key tables",60,y+54,12,Color.rgb(147,165,182),false);
            txt(c,"›",getWidth()-48,y+43,30,Color.rgb(118,140,157),false);
        }
        void detail(Canvas c,Module m,int y){
            txt(c,"‹  "+m.name,22,y+18,17,Color.rgb(92,200,255),true);
            txt(c,m.description,22,y+50,13,Color.rgb(147,165,182),false);
            int yy=y+78;
            for(String[] t:m.tables){
                round(c,18,yy,getWidth()-18,yy+65,18,Color.rgb(17,28,39));
                txt(c,t[0],34,yy+27,16,Color.rgb(243,247,251),true);
                txt(c,t[1],34,yy+48,12,Color.rgb(69,211,156),false);
                yy+=75;
            }
            round(c,18,yy+4,getWidth()-18,yy+72,18,Color.rgb(14,33,44));
            txt(c,"Architect lens",34,yy+29,15,Color.rgb(92,200,255),true);
            txt(c,m.arch,34,yy+52,12,Color.rgb(180,195,208),false);
        }

        void learn(Canvas c){
            header(c,"Learning studio","Learn • test • improve","Short sessions designed for ServiceNow developers.");
            int y=176;
            if(quizMode){
                Quiz qz=quizzes.get(quizIndex);
                round(c,18,y,getWidth()-18,y+370,24,Color.rgb(17,28,39));
                txt(c,"QUIZ  "+(quizIndex+1)+" / "+quizzes.size(),36,y+32,11,Color.rgb(69,211,156),true);
                int ty=y+72;
                for(String line:wrap(qz.q,34)){
                    txt(c,line,36,ty,17,Color.rgb(243,247,251),true); ty+=25;
                }
                ty+=14;
                for(int i=0;i<qz.options.length;i++){
                    int col = (quizSelected==i) ? Color.rgb(31,67,82) : Color.rgb(13,24,34);
                    round(c,32,ty,getWidth()-32,ty+50,16,col);
                    txt(c,(char)('A'+i)+"  "+qz.options[i],48,ty+31,14,Color.rgb(226,235,242),false);
                    ty+=62;
                }
                if(quizSelected>=0){
                    boolean ok=quizSelected==qz.answer;
                    txt(c,ok?"✓ Correct":"✕ Not quite",36,y+350,14,ok?Color.rgb(69,211,156):Color.rgb(255,122,122),true);
                } else {
                    txt(c,"Tap an answer to check yourself.",36,y+350,12,Color.rgb(147,165,182),false);
                }
                round(c,18,y+390,getWidth()-18,y+446,18,Color.rgb(14,33,44));
                txt(c,quizIndex==quizzes.size()-1?"Finish":"Next question",getWidth()/2-55,y+425,14,Color.rgb(92,200,255),true);
                return;
            }
            round(c,18,y,getWidth()-18,y+102,24,Color.rgb(17,28,39));
            txt(c,"DAILY CHALLENGE",36,y+30,11,Color.rgb(69,211,156),true);
            txt(c,"Can you explain ACL vs UI Policy?",36,y+58,17,Color.rgb(243,247,251),true);
            txt(c,"2 minutes  •  Security",36,y+81,12,Color.rgb(147,165,182),false);
            y+=118;
            round(c,18,y,getWidth()-18,y+62,18,Color.rgb(14,33,44));
            txt(c,"▶  Start 5-question knowledge check",34,y+38,15,Color.rgb(92,200,255),true);
            y+=88;
            txt(c,"LEARNING PATH",24,y,11,Color.rgb(147,165,182),true); y+=24;
            String[][] path={{"01","Platform foundations","Tables, records, applications, scopes"},{"02","Scripting","Client/server, Glide APIs, debugging"},{"03","Automation","Flow Designer, events, scheduled work"},{"04","Security","Roles, ACLs, application access"},{"05","Integrations","REST, SOAP, auth, import sets"},{"06","Architecture","Data model, performance, governance"}};
            for(String[] a:path){
                round(c,18,y,getWidth()-18,y+66,18,Color.rgb(17,28,39));
                txt(c,a[0],34,y+29,12,Color.rgb(92,200,255),true);
                txt(c,a[1],72,y+27,15,Color.rgb(243,247,251),true);
                txt(c,a[2],72,y+48,11,Color.rgb(147,165,182),false); y+=76;
            }
        }

        ArrayList<String> wrap(String s, int maxChars){
            ArrayList<String> out=new ArrayList<>();
            for(String part:s.split(" ")){
                if(out.isEmpty() || out.get(out.size()-1).length()+part.length()+1>maxChars) out.add(part);
                else out.set(out.size()-1,out.get(out.size()-1)+" "+part);
            }
            return out;
        }

        void dev(Canvas c){
            header(c,"Developer desk","Build with confidence","Reference the concepts you use in real ServiceNow work.");
            int y=176;
            if(selected>=0){
                Concept x=concepts.get(selected);
                txt(c,"‹  "+x.title,22,y+18,18,Color.rgb(92,200,255),true);
                txt(c,x.category.toUpperCase(Locale.US),22,y+48,11,Color.rgb(69,211,156),true);
                y+=75;
                for(String line:x.body.split("\n")){
                    txt(c,line,24,y,14,Color.rgb(220,231,239),false); y+=23;
                    if(y>getHeight()-30) break;
                }
                return;
            }
            int shown=0;
            for(int i=0;i<concepts.size();i++){
                Concept x=concepts.get(i);
                if(query.length()>0 && !x.title.toLowerCase().contains(query.toLowerCase()) && !x.category.toLowerCase().contains(query.toLowerCase())) continue;
                round(c,18,y,getWidth()-18,y+82,20,Color.rgb(17,28,39));
                txt(c,x.category,34,y+25,10,Color.rgb(92,200,255),true);
                txt(c,x.title,34,y+52,16,Color.rgb(243,247,251),true);
                txt(c,"Reference + example + architect note  ›",34,y+71,10,Color.rgb(147,165,182),false);
                y+=94; if(++shown>=8) break;
            }
        }

        void saved(Canvas c){
            header(c,"Your workspace","Saved for later","Keep important concepts and tables close at hand.");
            int y=180;
            round(c,18,y,getWidth()-18,y+112,24,Color.rgb(17,28,39));
            txt(c,"★  No saved items yet",36,y+42,18,Color.rgb(243,247,251),true);
            txt(c,"Tap Save on future lessons and references.",36,y+70,13,Color.rgb(147,165,182),false);
            txt(c,"Your saved content stays on this device.",36,y+92,12,Color.rgb(69,211,156),false);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){ downY=e.getY(); return true; }
            if(e.getAction()==MotionEvent.ACTION_UP){
                float x=e.getX(), y=e.getY();
                if(Math.abs(y-downY)>40) return true;
                if(page==0 && y>175){
                    if(selected>=0 && y<215){ selected=-1; invalidate(); return true; }
                    int idx=(int)((y-175)/92);
                    if(idx>=0 && idx<modules.size() && query.length()==0){ selected=idx; invalidate(); }
                } else if(page==1){
                    if(quizMode){
                        Quiz qz=quizzes.get(quizIndex);
                        int optionTop=176+72+25+14;
                        for(int i=0;i<qz.options.length;i++){
                            int top=optionTop+i*62;
                            if(y>=top && y<=top+50){ quizSelected=i; invalidate(); return true; }
                        }
                        if(y>=566 && y<=630){
                            if(quizIndex<quizzes.size()-1){ quizIndex++; quizSelected=-1; }
                            else { quizIndex=0; quizSelected=-1; quizMode=false; }
                            invalidate(); return true;
                        }
                    } else if(y>=294 && y<=360){
                        quizMode=true; quizIndex=0; quizSelected=-1; invalidate(); return true;
                    }
                } else if(page==2 && y>175){
                    if(selected>=0 && y<215){ selected=-1; invalidate(); return true; }
                    int idx=(int)((y-175)/94);
                    if(idx>=0 && idx<concepts.size()){ selected=idx; invalidate(); }
                }
                return true;
            }
            return true;
        }
    }

    static class Module {
        String name,tag,description,arch; int color; String[][] tables;
        Module(String n,String t,String d,String a,int c,String[][] ts){name=n;tag=t;description=d;arch=a;color=c;tables=ts;}
    }
    static class Concept { String title,category,body; Concept(String t,String c,String b){title=t;category=c;body=b;} }
    static class Quiz { String q; String[] options; int answer; Quiz(String q,String[] o,int a){this.q=q;options=o;answer=a;} }

    static class Data {
        static void seed(ArrayList<Module> m,ArrayList<Concept> c,ArrayList<Quiz> q){
            int blue=Color.rgb(92,200,255), green=Color.rgb(69,211,156), purple=Color.rgb(111,124,255), orange=Color.rgb(246,181,92), pink=Color.rgb(224,113,166);
            m.add(new Module("IT Service Management","ITSM","Manage incidents, problems, changes, requests and knowledge.","Use the task hierarchy, shared data, SLAs, assignment and automation as your design backbone.",green,new String[][]{{"Incident","incident"},{"Problem","problem"},{"Change Request","change_request"},{"Catalog Item","sc_cat_item"},{"Catalog Request","sc_request"},{"Requested Item","sc_req_item"},{"Catalog Task","sc_task"},{"Knowledge Article","kb_knowledge"},{"SLA Definition","contract_sla"}}));
            m.add(new Module("Configuration Management","CMDB","Model configuration items, relationships and service context.","Think CSDM, CI classes, relationships, identification and reconciliation before custom tables.",purple,new String[][]{{"Configuration Item","cmdb_ci"},{"Server","cmdb_ci_server"},{"Computer","cmdb_ci_computer"},{"CI Relationship","cmdb_rel_ci"},{"Discovery Model","cmdb_model"}}));
            m.add(new Module("IT Operations Management","ITOM","Observe infrastructure and services, correlate signals and automate operations.","Connect monitoring signals to CIs and services; keep operational data tied to business context.",blue,new String[][]{{"Event","em_event"},{"Alert","em_alert"},{"MetricBase Metric","metricbase_metric"},{"Service","cmdb_ci_service"}}));
            m.add(new Module("IT Asset Management","ITAM","Track hardware, software and lifecycle ownership.","Separate financial/physical asset concepts from configuration items and define lifecycle controls.",orange,new String[][]{{"Asset","alm_asset"},{"Hardware Asset","alm_hardware"},{"Software Asset","alm_license"},{"Model","cmdb_model"},{"Stockroom","alm_stockroom"}}));
            m.add(new Module("Customer Service Management","CSM","Resolve customer cases across channels, products and accounts.","Design around customer/account context, case lifecycle, entitlements and knowledge.",pink,new String[][]{{"Case","sn_customerservice_case"},{"Account","customer_account"},{"Contact","customer_contact"},{"Consumer","csm_consumer"}}));
            m.add(new Module("Human Resources Service Delivery","HRSD","Deliver employee services, cases, knowledge and lifecycle processes.","Protect sensitive employee data with strong roles, ACLs, criteria and separation of duties.",purple,new String[][]{{"HR Case","sn_hr_core_case"},{"HR Profile","sn_hr_core_profile"},{"HR Service","sn_hr_core_service"},{"HR Task","sn_hr_core_task"}}));
            m.add(new Module("Security Operations","SecOps","Coordinate security incidents, vulnerabilities and security workflows.","Integrate security signals, enrich with CMDB context and automate response with least privilege.",orange,new String[][]{{"Security Incident","sn_si_incident"},{"Vulnerability","sn_vul_vulnerable_item"},{"Security Case","sn_si_case"},{"Security Incident Task","sn_si_task"}}));
            m.add(new Module("Strategic Portfolio Management","SPM","Plan portfolios, projects, resources, demands and investment decisions.","Design a coherent demand-to-delivery model with governance, financials and portfolio hierarchy.",green,new String[][]{{"Project","pm_project"},{"Demand","dmn_demand"},{"Project Task","pm_project_task"},{"Resource Plan","resource_plan"}}));
            m.add(new Module("Field Service Management","FSM","Coordinate field work, dispatch, skills, parts and mobile execution.","Model work orders, tasks, agents, territories and inventory while keeping dispatch efficient.",blue,new String[][]{{"Work Order","wm_order"},{"Work Order Task","wm_task"},{"Agent","wm_agent"},{"Part Requirement","wm_part_requirement"}}));
            m.add(new Module("Governance, Risk & Compliance","GRC","Manage risk, controls, policies, audits and compliance workflows.","Start with policy/control relationships, ownership, evidence, scoring and auditable workflows.",pink,new String[][]{{"Risk","sn_risk_risk"},{"Control","sn_compliance_control"},{"Policy","sn_compliance_policy"},{"Audit","sn_audit_engagement"}}));
            m.add(new Module("Application Development","Platform","Build scoped applications with tables, scripts, flows, experiences and security.","Prefer standard platform capabilities, scoped APIs, reusable services, clear data models and upgrade-safe customization.",blue,new String[][]{{"Application","sys_scope"},{"Dictionary Entry","sys_dictionary"},{"Business Rule","sys_script"},{"Client Script","sys_script_client"},{"Script Include","sys_script_include"},{"UI Policy","sys_ui_policy"},{"ACL","sys_security_acl"},{"Update Set","sys_update_xml"}}));
            m.add(new Module("Integration & APIs","Integration","Connect ServiceNow to external systems using APIs, imports and integration patterns.","Choose authentication, retry, idempotency, error handling, observability and ownership before implementation.",green,new String[][]{{"REST Message","sys_rest_message"},{"REST Method","sys_rest_message_fn"},{"Import Set","sys_import_set"},{"Transform Map","sys_transform_map"},{"Credential","sys_auth_profile"}}));
            m.add(new Module("Automation & Platform","Automation","Automate work with Flow Designer, events, notifications, schedules and actions.","Use Flow Designer for maintainable process automation; reserve scripts for logic that truly needs code.",purple,new String[][]{{"Flow","sys_hub_flow"},{"Flow Context","sys_flow_context"},{"Event Registry","sysevent_register"},{"Event Log","sysevent"},{"Scheduled Job","sysauto_script"},{"Notification","sysevent_email_action"}}));

            c.add(new Concept("GlideRecord","Server-side API","GlideRecord is the primary server-side API for querying and manipulating records.\n\nPattern:\nvar gr = new GlideRecord('incident');\ngr.addActiveQuery();\ngr.query();\nwhile (gr.next()) { gs.info(gr.number); }\n\nArchitect note: control query size, index-friendly filters and avoid unnecessary nested queries."));
            c.add(new Concept("Business Rules","Server-side","Use Business Rules for server-side logic triggered around database operations.\n\nArchitect note: keep rules focused, avoid hidden side effects, and consider Flow Designer when the requirement is process automation rather than transactional enforcement."));
            c.add(new Concept("Client Scripts","Client-side","Client Scripts run in the browser for form/list behavior such as onLoad, onChange and onSubmit.\n\nArchitect note: client logic is not a security boundary. Sensitive access must be enforced server-side with ACLs."));
            c.add(new Concept("ACLs","Security","Access Controls determine whether a user can create, read, write or delete protected data.\n\nArchitect note: design security early, use roles and conditions deliberately, and test with impersonation or representative personas."));
            c.add(new Concept("Script Includes","Server-side API","Script Includes package reusable server-side functions/classes.\n\nArchitect note: prefer reusable services over duplicated logic. Respect application scope and API accessibility."));
            c.add(new Concept("Flow Designer","Automation","Flow Designer creates maintainable process automation using triggers, actions, flow logic, subflows and reusable components.\n\nArchitect note: use it for business process orchestration; keep complex data logic in reusable server-side APIs where appropriate."));
            c.add(new Concept("Scoped Applications","Architecture","Scoped apps isolate application artifacts and control cross-scope access.\n\nArchitect note: define application boundaries, APIs and application access explicitly. Avoid accidental global dependencies."));
            c.add(new Concept("Data Model","Architecture","A strong ServiceNow solution begins with a clear data model: tables, extensions, references, ownership and lifecycle.\n\nArchitect note: changing the model late can force extensive rework across logic, security and experiences."));
            c.add(new Concept("Integration Design","Architecture","Integration design should cover authentication, contracts, retries, idempotency, error handling, monitoring and ownership.\n\nArchitect note: avoid point-to-point sprawl when a stable integration pattern or hub can reduce coupling."));
            c.add(new Concept("CSDM","CMDB","The Common Service Data Model provides a framework for organizing service and configuration data consistently.\n\nArchitect note: design business/application/technical service context before inventing custom relationship structures."));
            c.add(new Concept("Update Sets","Deployment","Update Sets capture configuration changes for movement between instances, but not every type of data or deployment scenario.\n\nArchitect note: use disciplined source control and deployment practices; know what your application actually tracks."));
            c.add(new Concept("ATF","Testing","Automated Test Framework helps validate platform behavior and application experiences.\n\nArchitect note: build regression coverage around critical workflows, security and integrations—not only happy-path forms."));

            q.add(new Quiz("Which mechanism is the strongest primary security boundary for table data?",new String[]{"Client Script","UI Policy","ACL","Catalog UI Policy"},2));
            q.add(new Quiz("Which API is commonly used for server-side record queries?",new String[]{"GlideRecord","g_form","g_list","GlideModal"},0));
            q.add(new Quiz("What should you design early because changing it later can cause extensive rework?",new String[]{"Color palette","Data model","Dashboard icon","User avatar"},1));
            q.add(new Quiz("Which is better suited to business process orchestration?",new String[]{"Flow Designer","CSS","Client-side alert","Browser bookmark"},0));
            q.add(new Quiz("Which statement is true about client-side security?",new String[]{"It is the strongest security boundary","It replaces ACLs","It should not be relied on for sensitive data","It is enforced before every API call"},2));
        }
    }
}
