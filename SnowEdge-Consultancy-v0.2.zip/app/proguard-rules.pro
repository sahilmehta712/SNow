# SnowEdge Consultancy prototype
